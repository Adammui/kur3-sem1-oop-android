package rudenia.fit.bstu.stpms12lab.model




data class Coord(
    val lat: Double,
    val lon: Double
)