package rudenia.fit.bstu.stpms12lab.model


import com.google.gson.annotations.SerializedName

data class Clouds(
    val all: Int
)